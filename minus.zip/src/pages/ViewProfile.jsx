import React from "react";
import DoctorBooking from "../components/viewprofile/DoctorBooking";

const ViewProfile = () => {
  return (
    <div>
      <DoctorBooking />
    </div>
  );
};

export default ViewProfile;
